from tkinter import *
from random import*

def next_problem():
    global x
    global y
    global problem_label
    global answer_entry
    global problem_text
    x = randrange(10)
    y = randrange(10)
    
    problem_text = str(x) + " + " +str(y) + " ="
    problem_label.configure(text = problem_text, bg = "lightblue")
    answer_entry.focus()
    
def check_answer():
    global answer_entry
    global next_problem
    answer = x + y
    try:
        user_answer = int(answer_entry.get())
        if user_answer == answer:
            feedback.configure(text = "Correct!", fg = "green", bg = "lightblue")
            answer_entry.delete(0, END)
            next_problem()
        else:
            feedback.configure(text = "Wrong!", fg = "red", bg = "lightblue") 
            answer_entry.delete(0, END)
            next_problem()
    except ValueError:
        feedback.configure(text = "That is not a number", fg = "black", bg = "lightblue")
        answer_entry.delete(0, END)
        answer_entry.focus()

def next_problem_subtraction():
    global x
    global y
    global problem_label
    global answer_entry
    global problem_text
    x = randrange(10)
    y = randrange(10)
    
    problem_text = str(x) + " - " +str(y) + " ="
    problem_label.configure(text = problem_text, bg = "lightblue")
    answer_entry.focus()
    
def check_answer_subtraction():
    global answer_entry
    global next_problem
    answer = x - y
    try:
        user_answer = int(answer_entry.get())
        if user_answer == answer:
            feedback.configure(text = "Correct!", fg = "green", bg = "lightblue")
            answer_entry.delete(0, END)
            next_problem_subtraction()
        else:
            feedback.configure(text = "Wrong!", fg = "red", bg = "lightblue") 
            answer_entry.delete(0, END)
            next_problem_subtraction()
    except ValueError:
        feedback.configure(text = "That is not a number", fg = "black", bg = "lightblue")
        answer_entry.delete(0, END)
        answer_entry.focus()            
        
def next_problem_multiplication():
    global x
    global y
    global problem_label
    global answer_entry
    global problem_text
    x = randrange(10)
    y = randrange(10)
    
    problem_text = str(x) + " x " +str(y) + " ="
    problem_label.configure(text = problem_text, bg = "lightblue")
    answer_entry.focus()
        
def check_answer_multiplication():
    global answer_entry
    global next_problem
    answer = x * y 
    try:
        user_answer = int(answer_entry.get())
        if user_answer == answer:
            feedback.configure(text = "Correct!", fg = "green", bg = "lightblue")
            answer_entry.delete(0, END)
            next_problem_multiplication()
        else:
            feedback.configure(text = "Wrong!", fg = "red", bg = "lightblue") 
            answer_entry.delete(0, END)
            next_problem_multiplication()
    except ValueError:
        feedback.configure(text = "That is not a number", fg = "black", bg = "lightblue")
        answer_entry.delete(0, END)
        answer_entry.focus()

def Screen1 ():
    #Creates a frame for the first 2 widgets
    global frame1
    global frame2
    
    frame2.grid_remove()
    frame1 = LabelFrame(root, bg = "lime green", height = 300)
    frame1.grid(row=0, column = 0)
    
    TitleLabel = Label (frame1, bg = "lime green", fg = "white", width = 20, padx = 30, pady = 10, text = "Welcome to Maths Mania", font= ("Times", "14", "bold"))
    TitleLabel.grid(columnspan = 5)
    
    button1 = Button(frame1, text = "Addition", font =("bold", "10"), bg = "white", pady= 10, anchor = W, command = Screen2)
    button1.grid(row = 8, column = 2)
    
    button2 = Button(frame1, text = "Subtraction", font =("bold", "10"), bg = "white", pady= 10, anchor = W, command = Screen3)
    button2.grid(row = 9, column = 2)

    button3 = Button(frame1, text = "Multiplication", font =("bold", "10"), bg = "white", pady= 10, anchor = W, command = Screen4)
    button3.grid(row = 10, column = 2)    

    
def Screen2():   
    global frame1
    global frame2    
    global next_problem  
    global problem_label
    global answer_entry
    global feedback
    global x
    global y
    
    frame1.grid_remove()
    frame2 = LabelFrame(root, height = "600", width = "300",  bg = "lightblue")
    frame2.grid(row=0, column = 0)
    
    problem_label = Label(frame2, text = "", width = 18, height = 3)
    problem_label.grid(row = 0, column = 0, sticky = W)
    
    answer_entry = Entry(frame2, width = 7)
    answer_entry.grid(row = 0, column = 1, sticky = W)
    
    check_btn = Button(frame2, text = "Check Answer", bg = "white", command = check_answer, relief = RIDGE)
    check_btn.grid(row = 1, column = 1)
    
    feedback = Label(frame2, text = "", height = 3, bg = "lightblue")
    feedback.grid(row = 2, column = 0)
    
    next_problem()
    
def Screen3():
    global frame1
    global frame2
    global next_problem
    global problem_label
    global answer_entry
    global feedback
    global x
    global y

    frame1.grid_remove()
    frame3 = LabelFrame(root, height = "600", width = "300", bg = "lightblue")
    frame3.grid(row=0, column = 0)
    
    problem_label = Label(frame3, text = "", width = 18, height = 3)
    problem_label.grid(row = 0, column = 0, sticky = W)
    
    answer_entry = Entry(frame3, width = 7)
    answer_entry.grid(row = 0, column = 1, sticky = W)
    
    check_btn = Button(frame3, text = "Check Answer", bg = "white", command = check_answer_subtraction, relief = RIDGE)
    check_btn.grid(row = 1, column = 1)
    
    feedback = Label(frame3, text = "", height = 3, bg = "lightblue")
    feedback.grid(row = 2, column = 0)

    next_problem_subtraction()
    
def Screen4():   
    global frame1
    global frame2    
    global next_problem_multiplication 
    global problem_label
    global answer_entry
    global feedback
    global x
    global y
    
    frame1.grid_remove()
    frame2 = LabelFrame(root, height = "600", width = "300",  bg = "lightblue")
    frame2.grid(row=0, column = 0)
    
    problem_label = Label(frame2, text = "", width = 18, height = 3)
    problem_label.grid(row = 0, column = 0, sticky = W)
    
    answer_entry = Entry(frame2, width = 7)
    answer_entry.grid(row = 0, column = 1, sticky = W)
    
    check_btn = Button(frame2, text = "Check Answer", bg = "white", command = check_answer_multiplication, relief = RIDGE)
    check_btn.grid(row = 1, column = 1)
    
    feedback = Label(frame2, text = "", height = 3, bg = "lightblue")
    feedback.grid(row = 2, column = 0)
    
    next_problem_multiplication()
    
    
root = Tk()
root.title("Maths Mania!")
#root.geometry("600x300+700+10")
frame1 = Frame(root)
frame2 = Frame(root)

Screen1()

root.mainloop()